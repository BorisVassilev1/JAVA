package edu.school.sedmitsa18;

import java.util.ArrayList;
import java.util.function.Function;

public class Main {

	public static void main(String[] args) {
		ArrayList<Integer> a = new ArrayList<Integer>();
		for(int i = 0 ; i < 10; i ++)
		{
			a.add((int) (Math.random() * 10));
		}
		System.out.println(a.toString());
		
		filter(a, (i) -> i.intValue() < 5);
		
		System.out.println(a.toString());
	}
	
	public static void filter (ArrayList<Integer> a, Function<Integer,Boolean> func)
	{
		for(int i = 0; i < a.size(); i ++)
		{
			if(!func.apply(i))
			{
				a.remove(i);
			}
		}
	}
	
}
