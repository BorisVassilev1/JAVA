package edu.vkashti.game3d;

public class Vector3 {
	float x;
	float y;
	float z;
	
	public Vector3(float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
}
