package edu.tutorial.application1;

import static org.lwjgl.opengl.GL11.*;

import java.awt.Cursor;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class Main {
	
	public static Texture tex;
	public static Camera cam;
	public static boolean isEsc = false;
	
	
	public static void main(String[] args) {
		initDisplay();

		gameLoop();
		cleanUp();
	}

	public static void initDisplay() {
		try {
			//Display.setDisplayMode(new DisplayMode(1200, 800));
			Display.setTitle("Game");
			Display.setResizable(true);
			Display.create();
		} catch (LWJGLException e) {
			// TODO Auto-generated catch block
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
		}
	}

	public static Texture loadTexture(String key) {
		try {
			return TextureLoader.getTexture("png", new FileInputStream(new File("res/" + key + ".png")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("problem loading the texture");
		}
		return null;
	}

	public static  void gameLoop() {
		tex = loadTexture("brick");
		cam = new Camera(70f, (float) Display.getWidth() / (float) Display.getHeight(), 0.3f, 1000f);
		float i = 0;

		
		tex.setTextureFilter(GL_NEAREST);
		
		
		
		while (!Display.isCloseRequested()) {
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			glLoadIdentity();
			cam.useView();

			if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
				cam.move(0.01f, 1);
			}

			if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
				cam.move(-0.01f, 1);
			}

			if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
				cam.move(0.01f, 0);
			}

			if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
				cam.move(-0.01f, 0);
			}

			if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) {
				cam.rotateY(-0.05f);
			}

			if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) {
				cam.rotateY(0.05f);
			}
			
			if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
				cam.moveY(-0.01f);
			}
			
			if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
				cam.moveY(0.01f);
			}
			
			if(Mouse.getDWheel() != 0)
			{
				isEsc = !isEsc;
			}
			if(!isEsc)
			{
				int mouseX = Mouse.getX();
				int mouseY = Mouse.getY();
				
				Mouse.setCursorPosition(Display.getWidth()/2, Display.getHeight()/2);
				
				int newMouseX = Mouse.getX();
				int newMouseY = Mouse.getY();
				
				int genDX = mouseX - newMouseX;
				int genDY = mouseY - newMouseY;
				
				cam.rotateY( (Mouse.getDX() + genDX) /20f);
				cam.rotateX( -(Mouse.getDY() + genDY) /20f);
				
				Mouse.updateCursor();	;
			}
			Draw.DrawCube(0, 0, -10, i, i, i, tex);
			glPushMatrix();
			{

				glTranslatef(0, -10, 0);
				//glRotatef(0, 1, 1, 0);

				tex.bind();
				
				
				
				glBegin(GL_QUADS);
				{
					glTexCoord2f(0, 0); glVertex3f(-20, 0, -20);
					glTexCoord2f(0, 1); glVertex3f(-20, 0,  20);
					glTexCoord2f(1, 1); glVertex3f( 20, 0,  20);
					glTexCoord2f(1, 0); glVertex3f( 20, 0, -20);
				}
				glEnd();
			}
			glPopMatrix();

			i += 0.03;

			Display.update();
		}
	}

	public static void cleanUp() {
		Display.destroy();
	}
}
