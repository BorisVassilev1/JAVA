package edu.tutorial.application1;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class Input {
	public static void handleInput()
	{
		if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
			Main.cam.move(0.01f, 1);
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
			Main.cam.move(-0.01f, 1);
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
			Main.cam.move(0.01f, 0);
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
			Main.cam.move(-0.01f, 0);
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) {
			Main.cam.rotateY(-0.05f);
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) {
			Main.cam.rotateY(0.05f);
		}
		
		if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
			Main.cam.moveY(-0.01f);
		}
		
		if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
			Main.cam.moveY(0.01f);
		}
		
		if(Mouse.getDWheel() != 0)
		{
			Main.isEsc = !Main.isEsc;
		}
	}
}
